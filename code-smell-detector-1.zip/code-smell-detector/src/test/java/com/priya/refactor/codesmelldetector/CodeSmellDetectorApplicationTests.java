package com.priya.refactor.codesmelldetector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodeSmellDetectorApplicationTests {

	@Test
	void contextLoads() {
	}

}
